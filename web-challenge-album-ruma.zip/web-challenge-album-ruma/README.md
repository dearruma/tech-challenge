Maven Net Coding Challenge
============

Setup
# install dependencies
npm install

# serve with hot reload at localhost:3000
npm start

# build for production with minification
npm run build
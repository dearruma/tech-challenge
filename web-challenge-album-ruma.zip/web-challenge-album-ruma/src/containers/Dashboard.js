import React from 'react';
import { Component } from 'react';
import PropTypes from 'prop-types'
import { connect } from 'react-redux';
import Users from './Users';
import Albums from './Albums';
import * as actions from '../actions';

class Dashboard extends Component {
  static propTypes = {
    errorMessage: PropTypes.string,
    isFetching: PropTypes.bool,
    users: PropTypes.array,
    albums: PropTypes.array,
    selectedUser: PropTypes.string
  }

  componentDidMount() {
    const { fetchUsersIfNeeded } = this.props;
    fetchUsersIfNeeded();
  }

  onChange = (e) => {
    const { fetchAlbums } = this.props;
    this.setState({selectedUser: e.target.value});
    fetchAlbums(e.target.value); 
  }

  render() {
    const { errorMessage, isFetching, users, albums, selectedUser} = this.props;
    return (
      <div>
      <Users errorMessage={errorMessage} isFetching={isFetching} users={users} onChange={this.onChange} selectedUser={selectedUser}/>
      {albums.length>0 && <Albums errorMessage={errorMessage} isFetching={isFetching} albums={albums}  />}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    errorMessage: state.errorMessage,
    isFetching: state.isFetching,
    users: state.users,
    albums: state.albums,
    selectedUser: state.selectedUser
  };
};

const mapDispatchToProps = dispatch => ({
  fetchUsersIfNeeded: () => dispatch(actions.fetchUsersIfNeeded()),
  fetchAlbums: userId => dispatch(actions.fetchAlbums(userId)),
  
});

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);

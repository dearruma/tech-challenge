import React from 'react';
import { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import * as actions from '../actions';

import Panel from '../components/Panel';
import Photo from '../components/Photo';
import Card from '../components/Card';

class Photos extends Component {
  static propTypes = {
    errorMessage: PropTypes.string,
    isFetching: PropTypes.bool,
    photos: PropTypes.array,
  }

  componentDidMount() {
    const { match: { params: { albumId } }, fetchPhotos } = this.props;
    fetchPhotos(albumId);
  }

  renderPhotos = () => {
    const { photos } = this.props;
    if (!photos) return null;
    return photos.map(({ id, url, title }) => (
      <Card  key={id} link={url}>
          <Photo key={id}>
            <img src={url} alt={title} /><p>{title}</p>
          </Photo>
      </Card>
    ));
  }

  render() {
    const { errorMessage, isFetching } = this.props;
    return (
      <div className="album py-5 bg-light">
        <div className="container">
          <div className="row">
            <Panel title="Photos" errorMessage={errorMessage} isFetching={isFetching}>
            <div className="row">{this.renderPhotos()}</div>
            </Panel>
          </div>
        </div>
      </div>

    );
  }
}

const mapStateToProps = state => ({
  errorMessage: state.errorMessage,
  isFetching: state.isFetching,
  photos: state.photos,
});

const mapDispatchToProps = dispatch => ({
  fetchPhotos: albumId => dispatch(actions.fetchPhotos(albumId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Photos);

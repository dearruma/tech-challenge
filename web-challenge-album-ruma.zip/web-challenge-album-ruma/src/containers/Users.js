import React from 'react';
import { Component } from 'react';
import PropTypes from 'prop-types';
import NotFound from '../components/NotFound';


class Users extends Component {
  static propTypes = {
    errorMessage: PropTypes.string,
    isFetching: PropTypes.bool,
    users: PropTypes.array,
  }


  renderUsers = () => {
    const { users } = this.props;
    if (!users) return null;
    return users.map(({ id, name }) => (
      <option value={id} key={id}>
        {name}
      </option>
    ));
  }

  render() {
    const { onChange, selectedUser, users } = this.props;
    const numUser = users.length;
    return (
      <section className="jumbotron text-center"> {numUser > 0 &&
        <div className="container">
          <p className="lead text-muted">Select User to see the album</p>
          <div title="Users">
            <select onChange={onChange} value={selectedUser}>
              <option value="">Select One</option>
              {this.renderUsers()}
            </select>
          </div>

        </div>}
      </section>
    );
  }
}

export default Users;

import React from 'react';
import { Component } from 'react';
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom';

import styled from 'styled-components';
import Panel from '../components/Panel';
import Card from '../components/Card';

const StyledLink = styled(Link)`
  position: relative;
  min-height: 40px;
  width: 100%;
  padding: 10px;
  display: flex;
  align-items: center;
  background-color: #ffffff;
  cursor: pointer;
  color: #444;
  text-decoration: none;
  line-height: 1;
  font-size: 1rem;
  user-select: none;
  transition: box-shadow 0.2s ease-out;
  box-shadow: 0 6px 4px -4px transparent;

  &:hover {
    box-shadow: 0 6px 4px -4px rgba(0,0,0,0.1);
    transition: box-shadow 0.2s ease-in;
  }
`;

class Albums extends Component {
  static propTypes = {
    errorMessage: PropTypes.string,
    isFetching: PropTypes.bool,
    albums: PropTypes.array,
  }

  renderAlbums = () => {
    const { albums } = this.props;
    if (!albums) return null;
    return albums.map(({ id, title }) => (
      <Card key={id}>
       <StyledLink to={`/photos/${id}`}>{title}</StyledLink>
      </Card>
    ));
  }

  render() {
    const { errorMessage, isFetching } = this.props;
    return (
      <div className="album py-5 bg-light">
        <div className="container">
          <div className="row">
            <Panel title="Albums" errorMessage={errorMessage} isFetching={isFetching}>
              {this.renderAlbums()}
            </Panel>
          </div>
        </div>
      </div>
    );
  }
}
export default Albums;

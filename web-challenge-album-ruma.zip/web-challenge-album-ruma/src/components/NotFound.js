import React from 'react';

import Panel from './Panel';

const NotFound = () => (
  <Panel title="Not Found" errorMessage="Something went wrong!" />
);

export default NotFound;

import React from 'react';
import PropTypes from 'prop-types';

const Card = ({ link, children }) => (
  <div className="col-md-4">
    <div className="card mb-4 shadow-sm">
      <div className="card-body">
        {children}
      </div>
    </div>
  </div>
);

Card.propTypes = {
  link: PropTypes.string,
  children: PropTypes.node,
}

export default Card;
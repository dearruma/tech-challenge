import styled from 'styled-components';

const Photo = styled.div`
  background: #ffffff;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 10px;
  width: 100%;
  position: relative;
  transition: .5s ease-out;

  > img  {
    width:100%;
    position: relative;
    
  }
  &:hover {
    p {
      opacity: 1
    }
    img {
      opacity: 0.3;
    }
  }
  p {
    font-size: 1rem;
    position:absolute;
    bottom: 1%;
    background: rgba(0, 0, 0, 0.1);
    width:93.5%;
    padding:8px;
    transform: translate3d(0,10px,0);
    min-height: 80px;
    opacity: 0;
  }
`;

export default Photo;
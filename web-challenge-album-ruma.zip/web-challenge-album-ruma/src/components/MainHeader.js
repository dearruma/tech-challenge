import React from 'react';

const MainHeader = () => (
  <div className="bg-dark">
    <nav className="navbar navbar-dark bg-dark shadow-sm">
      <div className="container d-flex justify-content-between">
        <a className="navbar-brand d-flex align-items-center text-uppercase" href="/"><i className="fa fa-picture-o tm-brand-icon"></i>Photo Album Gallery</a>
      </div>
    </nav>
  </div>
);

export default MainHeader;

import React from 'react';
import { render } from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Provider } from 'react-redux';
import configureStore from './store/configureStore.dev';
import './main.scss';
import Dashboard from './containers/Dashboard';
import Albums from './containers/Albums';
import Photos from './containers/Photos';
import NotFound from './components/NotFound';
import MainHeader from './components/MainHeader';

const store = configureStore();

render(
  <Provider store={store}>
    <Router>
      <div>
        <MainHeader />
        <Switch>
          <Route exact path="/" component={Dashboard} />
          <Route path="/albums/:userId" component={Albums} />
          <Route path="/photos/:albumId" component={Photos} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </Router>
  </Provider>,
  document.getElementById('root')
);